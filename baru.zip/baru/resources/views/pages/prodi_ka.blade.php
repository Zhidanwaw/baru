@extends('layouts.index')
@section('heading', 'program studi Komputerisasi Akutansi')
@section('page')
    <a href="" class="text-capitalize">program studi</a>
    <span class="mx-3 fas fa-angle-right"></span>
    <span class="current">Komputerisasi Akutansi</span>
@endsection
@section('content')

    {{-- prodi Komputerisasi Akutansi  begin --}}
    <section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6">
                    <div class="card-title about__text mb-5">
                        <div class="section-title pb-4">
                            <h4 class="text-center">Profil Singkat</h4>
                            <p>Poliwangi telah menjadi perguruan tinggi yang memberikan lulusan terbaiknya kepada bangsa dan
                                negara. Capaian itu kita syukuri dengan mengamati lulusan banyak berkiprah di berbagai
                                sektor industri dan instansi di tanah air ini. Poliwangi yang bertekad menjadi menjadi
                                Technopreneurs Politeknik yang berwawasan Global telah menentukan arah untuk mendorong
                                mahasiswa untuk menjadi Technopreneurs dengan menciptakan berbagai inovasi berdasarkan mata
                                kuliah yang ditempuh sehingga bermanfaat bagi masyarakat. Memiliki wawasan untuk bisa
                                berperan aktif baik secara nasional maupun internasional dengan inisiasi menjalin hubungan
                                dengan berbagai perguruan tinggi di luar negeri.</p>
                        </div>
                        <div class="section-title pb-4">
                            <h4 class="text-center">VISI</h4>
                            <p>Menjadi Lembaga Pendidikan Tinggi vokasional yang bermutu, berkemampuan ilmu pengetahuan dan
                                teknologi, inovatif, dan berdaya saing.</p>
                        </div>
                        <div class="section-title pb-4">
                            <h4 class="text-center">MISI</h4>
                            <ol>
                                <li> Menyelenggarakan pendidikan yang bermutu sesuai standar nasional pendidikan tinggi
                                    untuk menghasilkan lulusan yang kompeten dan profesional;.</li>
                                <li>Melaksanakan penelitian terapan dan pengabdian kepada masyarakat dalam rangka
                                    meningkatkan kualitas Sivitas Akademika sesuai dengan permasalahan industri dan
                                    masyarakat.</li>
                                <li>Meningkatkan akses, relevansi, kemampuan ilmu pengetahuan dan teknologi dan invoasi
                                    untuk sumber daya manusia yang berkualitas.</li>
                            </ol>
                        </div>
                        <div class="section-title pb-4">
                            <h4 class="text-center mb-3">SASARAN PENCAPAIAN</h4>
                            <ol>
                                <li> Menghasilkan lulusan dengan IPK 3,0.</li>
                                <li> Menghasilkan Penelitian dan publikasi ilmiah bereputasi nasional statu judul per
                                    tahun. </li>
                                <li> Menghasilkan Pengabdian masyarakat yang di biaya oleh insitusi di luar kampus
                                    sebanyak 2 pengabdian.</li>
                                <li> Menghasilkan lulusan yeng menguasai teknologi informasi yang adaftif terhadap
                                    perkembangan
                                    teknologi informasi sebesar 60% (tanggapan stakeholder/ pengguna lulusan)</li>
                            </ol>
                        </div>
                        <div class="section-title">
                            <h4 class="text-center mb-4">STRATEGI PENCAPAIAN</h4>
                            <ol>
                                <li>Meningkatkan kualitas pendidikan dan pengajaran.</li>
                                <li>Meningkatkan kualitas dan publikasi</li>
                                <li>Meningkatkan kegiatan pengabdian kepada masyarkat</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {{-- prodi Komputerisasi Akutansi end --}}

@endsection
