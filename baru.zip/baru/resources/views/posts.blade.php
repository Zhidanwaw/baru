@extends('layouts.main')

@section('container')
    <h1>Halaman Posts</h1>
@endsection
