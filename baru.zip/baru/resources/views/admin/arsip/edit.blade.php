@extends('layout_admin.template')
@section('heading', 'Edit Data Arsip')

@section('page')
    <li class="breadcrumb-item active">Edit Arsip</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('arsip.update', $data->id) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label for="nama_alumni">Jenis Surat </label>
                                <select name="jenis surat" class="form-control @error('jenis_surat') is-invalid @enderror">
                                    <option value="{{ $data->jenis_surat }}">-- Jenis Surat --</option>
                                    <option value="Surat Masuk">Surat Masuk</option>
                                    <option value="Surat Keluar">Surat Keluar</option>
                                </select>
                                <div class="text-danger">
                                    @error('jenis_surat')
                                        Jenis Surat Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="no_surat">No Surat </label>
                                <input type="text" name="no_surat" value="{{ $data->no_surat }}"
                                    class="form-control @error('no_surat') is-invalid @enderror"
                                    placeholder="Masukkan no surat">
                                <div class="text-danger">
                                    @error('no_surat')
                                        No Surat Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="tgl_surat">Tanggal Surat </label>
                                <input type="date" name="tgl_surat" value="{{ $data->tgl_surat }}"
                                    class="form-control @error('tgl_surat') is-invalid @enderror"
                                    placeholder="Masukkan tanggal surat">
                                <div class="text-danger">
                                    @error('tgl_surat')
                                        Tanggal Surat Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="perihal">Perihal </label>
                                <input type="text" name="perihal" value="{{ $data->perihal }}"
                                    class="form-control @error('perihal') is-invalid @enderror"
                                    placeholder="Masukkan perihal surat">
                                <div class="text-danger">
                                    @error('perihal')
                                        Perihal Surat Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="pengirim">Pengirim </label>
                                <input type="text" name="pengirim" value="{{ $data->pengirim }}"
                                    class="form-control @error('pengirim') is-invalid @enderror"
                                    placeholder="Masukkan pengirim surat">
                                <div class="text-danger">
                                    @error('pengirim')
                                        Perihal Surat Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="file">Pilih File</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input  @error('file') is-invalid @enderror"
                                            name="file" value="{{ $data->file }}">
                                        <label class="custom-file-label" for="file">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('file')
                                        File Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="card-footer justify-content-between">
                                <a href="#" name="kembali" class="btn btn-default" id="back"><i
                                        class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</a> &nbsp;
                                <button type="submit" class="btn btn-primary float-right">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <!-- /.col -->

        <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- Extra large modal -->
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#back').click(function() {
                window.location = "{{ route('arsip.index') }}";
            });
        });

        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Arsip").addClass("active");
    </script>

@endsection
