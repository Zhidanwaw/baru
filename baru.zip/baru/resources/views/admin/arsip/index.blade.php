@extends('layout_admin.template')
@section('heading', 'Arsip Surat')

@section('page')
    <li class="breadcrumb-item active">Arsip</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                    data-target=".bd-example-modal-lg">
                                    <i class="nav-icon fas fa-folder-plus"></i> &nbsp; Tambah Data Arsip
                                </button>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th width="5%">No.</th>
                                        <th width="10%">Jenis Surat</th>
                                        <th width="15%">No Surat</th>
                                        <th width="10%">Tgl Surat</th>
                                        <th width="20%">Perihal</th>
                                        <th width="15%">Pengirim</th>
                                        <th width="10%">File</th>
                                        <th width="20%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($data as $row)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ $row->jenis_surat }}</td>
                                            <td>{{ $row->no_surat }}</td>
                                            <td>{{ $row->tgl_surat->format('d-m-Y') }}</td>
                                            <td>{{ $row->perihal }}</td>
                                            <td>{{ $row->pengirim }}</td>
                                            <td><a href="/arsippegawai/{{ $row->file }}"><button class="btn btn-success"
                                                        type="button">Download</button></a></td>
                                            </td>
                                            <td>

                                                <form action="{{ route('arsip.delete', $row->id) }}" method="post">
                                                    @csrf
                                                    @method('GET')
                                                    <a href="{{ route('arsip.edit', Crypt::encrypt($row->id)) }}"
                                                        class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                        &nbsp; Edit</a>

                                                    <button class="btn btn-danger btn-sm"><i
                                                            class="mr-2 nav-icon fas fa-trash-alt"></i>Hapus</button>
                                                </form>

                                                {{-- <a href="{{ route('arsip.edit', Crypt::encrypt($row->id)) }}"
                                                    class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                    &nbsp; Edit</a>

                                                <a href="#" class="btn btn-danger btn-sm delete"
                                                    data-id="{{ $row->id }}" data-nama="{{ $row->pengirim }}"><i
                                                        class="nav-icon fas fa-trash-alt"></i>
                                                    Hapus</a> --}}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- tambah data -->
    <div class="modal fade bd-example-modal-md bd-example-modal-lg" tabindex="-1" role="dialog"
        aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data Arsip</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('arsip.insert') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">

                            <div class="form-group">
                                <label for="link">Jenis Surat</label>
                                <select name="jenis_surat" class="form-control @error('jenis_surat') is-invalid @enderror">
                                    <option value="">-- Pilih Jenis Surat --</option>
                                    <option value="Surat Masuk">Surat Masuk</option>
                                    <option value="Surat Keluar">Surat Keluar</option>
                                </select>
                                <div class="text-danger">
                                    @error('jenis_surat')
                                        Jenis Surat Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">No Surat</label>
                                <input type="text" name="no_surat" value=""
                                    class="form-control @error('no_surat') is-invalid @enderror"
                                    placeholder="Masukkan No Surat">
                                <div class="text-danger">
                                    @error('no_surat')
                                        No Surat Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">Tgl Surat</label>
                                <input type="date" name="tgl_surat" value=""
                                    class="form-control @error('tgl_surat') is-invalid @enderror"
                                    placeholder="Masukkan Tanggal Surat">
                                <div class="text-danger">
                                    @error('tgl_surat')
                                        Tanggal Surat Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">Perihal</label>
                                <input type="text" name="perihal" value=""
                                    class="form-control @error('perihal') is-invalid @enderror"
                                    placeholder="Masukka Perihal Surat">
                                <div class="text-danger">
                                    @error('perihal')
                                        Perihal Surat Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="link">Pengirim</label>
                                <select name="pengirim" class="form-control @error('pengirim') is-invalid @enderror">
                                    <option value="">-- Pilih Pengirim --</option>
                                    <option value="direktur" @if (old('pengirim') == 'direktur') {{ 'selected' }} @endif>
                                        Direktur</option>
                                    <option value="pudir1">Pudir-1</option>
                                    <option value="pudir2">Pudir-2</option>
                                    <option value="pudir3">Pudir-3</option>
                                    <option value="manajemen">Manajemen</option>
                                    <option value="dosen">Dosen</option>
                                    <option value="pegawai">Pegawai</option>
                                </select>
                                <div class="text-danger">
                                    @error('pengirim')
                                        Pengirim tidak boleh kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="file">Pilih File</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file"
                                            class="custom-file-input  @error('file') is-invalid @enderror" name="file">
                                        <label class="custom-file-label" for="file">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('file')
                                        file tidak boleh kosong.
                                    @enderror
                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i
                                    class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</button>
                            <button type="submit" class="btn btn-primary"><i class="nav-icon fas fa-save"></i> &nbsp;
                                Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        $('.delete').click(function() {
            var arsipid = $(this).attr('data-id');
            var pengirim = $(this).attr('data-nama');
            swal({
                    title: "Yakin?",
                    text: "Kamu akan menghapus data pegawai dengan nama " + pengirim + " ",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/delete/" + arsipid,
                            swal("Data berhasil di hapus", {
                                icon: "success",
                            });
                    } else {
                        swal("Data tidak jadi di hapus");
                    }
                });
        });
    </script>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Arsip_masuk").addClass("active");
    </script>
@endsection
