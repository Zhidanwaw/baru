@extends('layout_admin.template')
@section('heading', 'Edit Data Kegiatan')

@section('page')
    <li class="breadcrumb-item active">Edit Kegiatan</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('event.update', $data->id) }}" method="post" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group">
                                <label for="foto">Pilih File</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input  @error('foto') is-invalid @enderror"
                                            name="foto" value="{{ $data->foto }}">
                                        <label class="custom-file-label" for="file">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('foto')
                                        File Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="judul">Judul Kegiatan </label>
                                <input type="text" name="judul" value="{{ $data->judul }}"
                                    class="form-control @error('judul') is-invalid @enderror"
                                    placeholder="Masukkan judul kegiatan">
                                <div class="text-danger">
                                    @error('judul')
                                        Nama Industri Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi Kegiatan</label>
                                <input type="text" name="deskripsi" value="{{ $data->deskripsi }}"
                                    class="form-control @error('deskripsi') is-invalid @enderror"
                                    placeholder="Masukkan deskripsi industri">
                                <div class="text-danger">
                                    @error('deskripsi')
                                        Deskripsi Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="card-footer justify-content-between">
                                <a href="#" name="kembali" class="btn btn-default" id="back"><i
                                        class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</a> &nbsp;
                                <button type="submit" class="btn btn-primary float-right">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <!-- /.col -->

        <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    {{-- tes --}}
    <!-- /.content -->
    <!-- Extra large modal -->
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#back').click(function() {
                window.location = "{{ route('kerjasama.index') }}";
            });
        });

        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Event").addClass("active");
    </script>

@endsection
