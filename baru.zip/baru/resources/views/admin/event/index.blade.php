@extends('layout_admin.template')
@section('heading', 'Kegiatan')

@section('page')
    <li class="breadcrumb-item active">Kegiatan</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                    data-target=".bd-example-modal-lg">
                                    <i class="nav-icon fas fa-folder-plus"></i> &nbsp; Tambah Data Kegiatan
                                </button>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th width="5%">No.</th>
                                        <th width="20%">Foto Kegiatan</th>
                                        <th width="20%">Nama Kegiatan</th>
                                        <th width="20%">Deskripsi Kegiatan</th>
                                        <th width="20%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($data as $row)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>
                                                <img src="{{ asset('gambarkegiatan/' . $row->foto) }}" alt=""
                                                    style="width: 70px;">
                                            </td>
                                            <td>{{ $row->judul }}</td>
                                            <td>{{ $row->deskripsi }}</td>
                                            </td>
                                            <td>

                                                <form action="{{ route('event.delete', $row->id) }}" method="post">
                                                    @csrf
                                                    @method('GET')
                                                    <a href="{{ route('event.edit', Crypt::encrypt($row->id)) }}"
                                                        class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                        &nbsp; Edit</a>

                                                    <button class="btn btn-danger btn-sm"><i
                                                            class="mr-2 nav-icon fas fa-trash-alt"></i>Hapus</button>
                                                </form>

                                                {{-- <a href="{{ route('event.edit', Crypt::encrypt($row->id)) }}"
                                                    class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                    &nbsp; Edit</a>

                                                <a href="#" type="button" class="btn btn-danger btn-sm delete"
                                                    data-id="{{ $row->id }}" data-nama="{{ $row->judul }}"><i
                                                        class="nav-icon fas fa-trash-alt"></i>
                                                    Hapus</a> --}}

                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- tambah data -->
    <div class="modal fade bd-example-modal-md bd-example-modal-lg" tabindex="-1" role="dialog"
        aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data Kegiatan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('event.insert') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">

                            <div class="form-group">
                                <label for="foto">Foto Kegiatan</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input  @error('foto') is-invalid @enderror"
                                            name="foto">
                                        <label class="custom-file-label" for="foto">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('foto')
                                        Foto tidak boleh kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="judul">Nama Kegiatan</label>
                                <input type="text" name="judul" value=""
                                    class="form-control @error('judul') is-invalid @enderror"
                                    placeholder="Masukkan Nama Kegiatan">
                                <div class="text-danger">
                                    @error('judul')
                                        Judul Kegiatan Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi Kegiatan</label>
                                <input type="text" name="deskripsi" value=""
                                    class="form-control @error('deskripsi') is-invalid @enderror"
                                    placeholder="Masukkan Deskripsi">
                                <div class="text-danger">
                                    @error('deskripsi')
                                        Deskripsi Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>


                        </div>
                        <!-- /.card-body -->
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i
                                    class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</button>
                            <button type="submit" class="btn btn-primary"><i class="nav-icon fas fa-save"></i> &nbsp;
                                Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        $('.delete').click(function() {
            var eventid = $(this).attr('data-id');
            var judul = $(this).attr('data-nama');
            swal({
                    title: "Yakin?",
                    text: "Kamu akan menghapus data pegawai dengan nama " + judul + " ",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/admin/event/delete/" + eventid,
                            swal("Data berhasil di hapus", {
                                icon: "success",
                            });
                    } else {
                        swal("Data tidak jadi di hapus");
                    }
                });
        });
    </script>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Event").addClass("active");
    </script>
@endsection
