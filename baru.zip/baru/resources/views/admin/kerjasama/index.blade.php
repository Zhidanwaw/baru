@extends('layout_admin.template')
@section('heading', 'Kerjasama Industri')

@section('page')
    <li class="breadcrumb-item active">Kerjasama Industri</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                    data-target=".bd-example-modal-lg">
                                    <i class="nav-icon fas fa-folder-plus"></i> &nbsp; Tambah Data Kerjasama
                                </button>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th width="5%">No.</th>
                                        <th width="20%">Gambar</th>
                                        <th width="20%">Nama Industri</th>
                                        <th width="20%">Deskripsi Kerjasama</th>
                                        <th width="20%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($industri as $row)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>
                                                <img src="{{ Storage::url($row->gambar) }}" width="80px"
                                                    class="img-thumbnail">
                                            <td>{{ $row->nama }}</td>
                                            <td>{{ $row->deskripsi }}</td>
                                            </td>
                                            <td>
                                                <form action="{{ route('kerjasama.delete', $row->id) }}" method="post">
                                                    @csrf
                                                    @method('GET')
                                                    <a href="{{ route('kerjasama.edit', Crypt::encrypt($row->id)) }}"
                                                        class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                        &nbsp; Edit</a>

                                                    <button class="btn btn-danger btn-sm"><i
                                                            class="mr-2 nav-icon fas fa-trash-alt"></i>Hapus</button>
                                                </form>

                                                {{-- <a href="{{ route('kerjasama.edit', Crypt::encrypt($row->id)) }}"
                                                    class="btn btn-success btn-sm"><i class="nav-icon fas fa-edit"></i>
                                                    &nbsp; Edit</a>

                                                <a href="#" type="button" class="btn btn-danger btn-sm delete"
                                                    data-id="{{ $row->id }}" data-nama="{{ $row->nama }}"><i
                                                        class="nav-icon fas fa-trash-alt"></i>
                                                    Hapus</a> --}}


                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- tambah data -->
    <div class="modal fade bd-example-modal-md bd-example-modal-lg" tabindex="-1" role="dialog"
        aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data Kerjasama Industri</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('kerjasama.insert') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">

                            <div class="form-group">
                                <label for="gambar">Gambar Kerjasama</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file"
                                            class="custom-file-input  @error('gambar') is-invalid @enderror" name="gambar">
                                        <label class="custom-file-label" for="gambar">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('gambar')
                                        Gambar tidak boleh kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">Nama Industri</label>
                                <input type="text" name="nama" value=""
                                    class="form-control @error('nama') is-invalid @enderror"
                                    placeholder="Masukkan Nama Kerjasama">
                                <div class="text-danger">
                                    @error('nama')
                                        Nama Industri Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi Kerjasama</label>
                                <input type="text" name="deskripsi" value=""
                                    class="form-control @error('deskripsi') is-invalid @enderror"
                                    placeholder="Masukkan Deskripsi">
                                <div class="text-danger">
                                    @error('deskripsi')
                                        Deskripsi Tidak Boleh Kosong
                                    @enderror
                                </div>
                            </div>


                        </div>
                        <!-- /.card-body -->
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i
                                    class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</button>
                            <button type="submit" class="btn btn-primary"><i class="nav-icon fas fa-save"></i> &nbsp;
                                Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        $('.delete').click(function() {
            var pegawaiid = $(this).attr('data-id');
            var nama = $(this).attr('data-nama');
            swal({
                    title: "Yakin?",
                    text: "Kamu akan menghapus data pegawai dengan nama " + nama + " ",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.location = "/admin/delete/" + pegawaiid,
                            swal("Data berhasil di hapus", {
                                icon: "success",
                            });
                    } else {
                        swal("Data tidak jadi di hapus");
                    }
                });
        });
    </script>
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Kerjasama").addClass("active");
    </script>
@endsection
