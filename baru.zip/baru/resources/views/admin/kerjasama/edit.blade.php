@extends('layout_admin.template')
@section('heading', 'Edit Data Kerjasama Industri')

@section('page')
    <li class="breadcrumb-item active">Edit Kerjasama Industri</li>
@endsection
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('kerjasama.update', $industri->id) }}" method="post"
                            enctype="multipart/form-data">
                            @csrf

                            <div class="form-group">
                                <label for="gambar">Pilih File</label>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file"
                                            class="custom-file-input  @error('gambar') is-invalid @enderror" name="gambar"
                                            value="{{ $industri->gambar }}">
                                        <label class="custom-file-label" for="file">Pilih File</label>
                                    </div>
                                </div>
                                <div class="text-danger">
                                    @error('gambar')
                                        File Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nama">Nama Industri </label>
                                <input type="text" name="nama" value="{{ $industri->nama }}"
                                    class="form-control @error('nama') is-invalid @enderror"
                                    placeholder="Masukkan nama industri">
                                <div class="text-danger">
                                    @error('nama')
                                        Nama Industri Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi Kerjasama</label>
                                <input type="text" name="deskripsi" value="{{ $industri->deskripsi }}"
                                    class="form-control @error('deskripsi') is-invalid @enderror"
                                    placeholder="Masukkan deskripsi industri">
                                <div class="text-danger">
                                    @error('deskripsi')
                                        Deskripsi Tidak Boleh Kosong.
                                    @enderror
                                </div>
                            </div>

                            <div class="card-footer justify-content-between">
                                <a href="#" name="kembali" class="btn btn-default" id="back"><i
                                        class='nav-icon fas fa-arrow-left'></i> &nbsp; Kembali</a> &nbsp;
                                <button type="submit" class="btn btn-primary float-right">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <!-- /.col -->

        <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- Extra large modal -->
@endsection

@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#back').click(function() {
                window.location = "{{ route('kerjasama.index') }}";
            });
        });

        $(document).ready(function() {
            bsCustomFileInput.init();
        });

        $("#Kerjasama").addClass("active");
    </script>

@endsection
